package com.example.kauaimc;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.EditText;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {
    private EditText edPeso, edAltura;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        edPeso = findViewById(R.id.peso);
        edAltura = findViewById(R.id.altura);
    }
    public void calcularIMC(View view){
        Intent i = new Intent(this, Resultado.class);

        Bundle ebundle = new Bundle();

        ebundle.putFloat("peso", Float.parseFloat(edPeso.getText().toString()));
        ebundle.putFloat("altura", Float.parseFloat(edAltura.getText().toString()));
        i.putExtras(ebundle);

        startActivity(i);
    }


}

