package com.example.kauaimc;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.media.Image;
import android.os.Bundle;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;
import android.view.View;



public class Resultado extends AppCompatActivity {
    TextView tvAltura, tvPeso, tvImc, tvResult;
    ImageView imageViewR;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_resultado);

        tvAltura = findViewById(R.id.ResultadoAltura);
        tvPeso = findViewById(R.id.ResultadoPeso);
        tvImc = findViewById(R.id.ResultadoIMC);
        imageViewR = findViewById(R.id.imageView);
        tvResult = findViewById(R.id.IndicadorR);

        Intent intent = getIntent();
        Bundle bundle = intent.getExtras();

        Float peso, altura, imc;
             peso = bundle.getFloat("peso");
             altura = bundle.getFloat("altura");

             imc = bundle.getFloat("imc");
                  imc = peso / (altura * altura);

        tvAltura.setText(altura.toString());
        tvPeso.setText(peso.toString());
        tvImc.setText(imc.toString());

        if (imc < 18.5) {
            imageViewR.setImageResource(R.drawable.abaixopeso);
            tvResult.setText("Abaixo do peso");
        } else if (imc > 18.5 && imc < 24.9) {
            imageViewR.setImageResource(R.drawable.normal);
            tvResult.setText("Peso normal");
        } else if (imc > 24.9 && imc < 29.9) {
            imageViewR.setImageResource(R.drawable.sobrepeso);
            tvResult.setText("Sobrepeso");
        } else if (imc > 30 && imc < 34.9) {
            imageViewR.setImageResource(R.drawable.obesidade1);
            tvResult.setText("Obesidade grau 1");
        } else if (imc > 35 && imc < 39.9) {
            imageViewR.setImageResource(R.drawable.obesidade2);
            tvResult.setText("Obesidade grau 2");
        } else if (imc > 40) {
            imageViewR.setImageResource(R.drawable.obesidade3);
            tvResult.setText("Obesidade grau 3");
        }

    }
    public void Refazer(View view){
        Intent i = new Intent(this, MainActivity.class);
        startActivity(i);
    }
}


